"""
A package containing all the functionality and
configuration connected to the prometheus metrics
"""