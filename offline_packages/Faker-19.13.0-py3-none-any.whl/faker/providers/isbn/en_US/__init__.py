from .. import Provider as ISBNProvider


class Provider(ISBNProvider):
    pass
