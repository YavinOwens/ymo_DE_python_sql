"""fontTools.voltLib -- a package for dealing with Visual OpenType Layout Tool
(VOLT) files."""

# See
# http://www.microsoft.com/typography/VOLT.mspx
